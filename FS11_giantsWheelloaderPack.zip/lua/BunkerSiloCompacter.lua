--
-- BunkerSiloCompacter
--
-- @author  Stefan Geiger
-- @date  10/06/11
--
-- Copyright (C) GIANTS Software GmbH, Confidential, All Rights Reserved.

BunkerSiloCompacter = {};

function BunkerSiloCompacter.prerequisitesPresent(specializations)
    return true;
end;

function BunkerSiloCompacter:load(xmlFile)
    self.bunkerSiloCompactingScale = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.bunkerSiloCompacter#compactingScale"), 1);
    self.bunkerSiloCompactingRefNode = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.bunkerSiloCompacter#refNode"));
end;

function BunkerSiloCompacter:delete()
end;

function BunkerSiloCompacter:mouseEvent(posX, posY, isDown, isUp, button)
end;

function BunkerSiloCompacter:keyEvent(unicode, sym, modifier, isDown)
end;

function BunkerSiloCompacter:update(dt)
end;

function BunkerSiloCompacter:draw()
end;
