--
-- WheelLoader
-- Specialization for wheel loader
--
-- @author  Stefan Geiger
-- @date  16/06/11
--
-- Copyright (C) GIANTS Software GmbH, Confidential, All Rights Reserved.

WheelLoader = {}


function WheelLoader.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(Steerable, specializations);
end;

function WheelLoader:load(xmlFile)

    local motorSound3D  = getXMLString(xmlFile, "vehicle.motorSound3D#file");
    if motorSound3D  ~= nil and motorSound3D  ~= "" then
        motorSound3D  = Utils.getFilename(motorSound3D, self.baseDirectory);
        self.motorSound3DRadius = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.motorSound3D#radius"), 50);
        self.motorSound3DInnerRadius = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.motorSound3D#innerRadius"), 10);
        self.motorSound3DVolume = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.motorSound3D#volume"), 1);
        self.motorSound3D = createAudioSource("motorSound3D", motorSound3D, self.motorSound3DRadius, self.motorSound3DInnerRadius, self.motorSound3DVolume, 0);
        link(self.components[1].node, self.motorSound3D);
        setVisibility(self.motorSound3D, false);
    end;

end;

function WheelLoader:delete()
end;

function WheelLoader:mouseEvent(posX, posY, isDown, isUp, button)
end;

function WheelLoader:keyEvent(unicode, sym, modifier, isDown)
end;

function WheelLoader:update(dt)
end;

function WheelLoader:draw()
end;

function WheelLoader:onEnter(isControlling)
    if isControlling then
        setVisibility(self.motorSound3D, false);
    else
        -- enable motor sound for vehicles steered by other people in multiplayer
        setVisibility(self.motorSound3D, true);
    end;
end;

function WheelLoader:onLeave()
    setVisibility(self.motorSound3D, false);
end;
