-- @author  Stefan Geiger
-- @date  26/04/11
--
-- Copyright (C) GIANTS Software GmbH, Confidential, All Rights Reserved.

local modName = g_currentModName;

local Shovel_updateTick = Shovel.updateTick;

local RaycastCallback = {};

RaycastCallback.currentObjectFound = nil;

function RaycastCallback:findTrailerRaycastCallback(transformId, x, y, z, distance)

    local object = g_currentMission:getNodeObject(transformId);
    if object ~= nil and object.addShovelFillLevel ~= nil and object.getAllowShovelFillType ~= nil and object:getAllowShovelFillType(Fillable.FILLTYPE_MANURE) then
        RaycastCallback.currentObjectFound = object;
        return false;
    end;

    return true;

end;

function Shovel:updateTick(dt)

    if self:getIsActive() then
        if self.isServer then
            if self.manureIsFilled then
                if self.manureTipReferenceNode ~= nil and self.manureFillPlane ~= nil then
                    if self:getIsManureEmptying() then
                        -- do raycast and empty..

                        RaycastCallback.currentObjectFound = nil;
                        local x,y,z = getWorldTranslation(self.manureTipReferenceNode);
                        raycastAll(x, y, z, 0, -1, 0, "findTrailerRaycastCallback", 10, RaycastCallback);

                        if RaycastCallback.currentObjectFound ~= nil then
                            local delta = RaycastCallback.currentObjectFound:addShovelFillLevel(self, self.manureCapacity, Fillable.FILLTYPE_MANURE);
                            if delta ~= nil and delta > 0 then
                                self:setManureIsFilled(false);
                            end;
                        end;
                    end;
                end;
            end;
        end;
    end;

    Shovel_updateTick(self, dt);
end;