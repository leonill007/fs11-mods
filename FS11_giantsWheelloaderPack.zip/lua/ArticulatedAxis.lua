--
-- ArticulatedAxis
-- This is the specialization for vehicles which steer with an articulated axis (excavators, loaders ...)
--
-- @author  Stefan Geiger
-- @date  18/08/09
--
-- Copyright (C) GIANTS Software GmbH, Confidential, All Rights Reserved.

ArticulatedAxis = {};

function ArticulatedAxis.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(Steerable, specializations);
end;

function ArticulatedAxis:load(xmlFile)

    if self.isServer then
        local index = getXMLInt(xmlFile, "vehicle.articulatedAxis#componentJointIndex");
        if index ~= nil then
            local componentJoint = self.componentJoints[index+1];
            local rotSpeed = getXMLFloat(xmlFile, "vehicle.articulatedAxis#rotSpeed");
            local rotMax = getXMLFloat(xmlFile, "vehicle.articulatedAxis#rotMax");
            local rotMin = getXMLFloat(xmlFile, "vehicle.articulatedAxis#rotMin");
            if componentJoint ~= nil and rotSpeed ~= nil and rotMax ~= nil and rotMin ~= nil then
                rotSpeed = math.rad(rotSpeed);
                rotMax = math.rad(rotMax);
                rotMin = math.rad(rotMin);
                local entry = {};

                entry.componentJoint = componentJoint;
                entry.anchorActor = Utils.getNoNil(getXMLInt(xmlFile,  "vehicle.articulatedAxis#anchorActor"), 0);

                entry.rotMax = rotMax;
                entry.rotMin = rotMin;
                entry.rotSpeed = rotSpeed;


                local maxRotTime = rotMax/rotSpeed;
                local minRotTime = rotMin/rotSpeed;
                if minRotTime > maxRotTime then
                    local temp = minRotTime;
                    minRotTime = maxRotTime;
                    maxRotTime = temp;
                end;
                if maxRotTime > self.maxRotTime then
                    self.maxRotTime = maxRotTime;
                end;
                if minRotTime < self.minRotTime then
                    self.minRotTime = minRotTime;
                end;

                entry.curRot = 0;

                self.articulatedAxis = entry;
            end;
        end;
    end;
    
    self.lastRotatedTime = 0;
end;

function ArticulatedAxis:delete()
end;

function ArticulatedAxis:loadFromAttributesAndNodes(xmlFile, key, resetVehicles)
    return BaseMission.VEHICLE_LOAD_OK;
end;

function ArticulatedAxis:getSaveAttributesAndNodes(nodeIdent)
end;

function ArticulatedAxis:mouseEvent(posX, posY, isDown, isUp, button)
end;

function ArticulatedAxis:keyEvent(unicode, sym, modifier, isDown)
end;

function ArticulatedAxis:update(dt)

    if self:getIsActive() then
        if self.articulatedAxis ~= nil then
            if self.isServer and self.isControlled then
                if self.lastRotatedTime ~= self.rotatedTime then
                    self.lastRotatedTime = self.rotatedTime;
                    local steeringAngle = self.rotatedTime * self.articulatedAxis.rotSpeed;
                    if steeringAngle > self.articulatedAxis.rotMax then
                        steeringAngle = self.articulatedAxis.rotMax;
                    elseif steeringAngle < self.articulatedAxis.rotMin then
                        steeringAngle = self.articulatedAxis.rotMin;
                    end;
                    if math.abs(steeringAngle - self.articulatedAxis.curRot) > 0.001 then
                        setRotation(self.articulatedAxis.componentJoint.jointNode, 0, steeringAngle, 0);
                        setJointFrame(self.articulatedAxis.componentJoint.jointIndex, self.articulatedAxis.anchorActor, self.articulatedAxis.componentJoint.jointNode);
                        self.articulatedAxis.curRot = steeringAngle;
                    end;
                end;
            end;
        end;
    end;

end;

function ArticulatedAxis:draw()
end;
