--
-- AnimatedSteering
--
--
-- @author  Manuel Leithner
-- @date  30/04/12
--
-- Copyright (C) GIANTS Software GmbH, Confidential, All Rights Reserved.

AnimatedSteering = {};

function AnimatedSteering.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(Cylindered, specializations);
end;

function AnimatedSteering:load(xmlFile)
	
	local refWheel = getXMLInt(xmlFile, "vehicle.animatedSteering#refWheel");
	refWheel = self.wheels[refWheel];
	if refWheel ~= nil then
		self.animatedSteering = {};
		self.animatedSteering.refWheel = refWheel;
		
		self.animatedSteering.nodes = {};
		local i=0;
		while true do
			local baseName = string.format("vehicle.animatedSteering.node(%d)", i);
			if not hasXMLProperty(xmlFile, baseName) then
				break;
			end;
			local entry = {};
			entry.index = Utils.indexToObject(self.components, getXMLString(xmlFile, baseName.."#index"));
			entry.xMin = math.rad(Utils.getNoNil(getXMLFloat(xmlFile, baseName.."#xMin"), 0));
			entry.xMax = math.rad(Utils.getNoNil(getXMLFloat(xmlFile, baseName.."#xMax"), 0));
				
			table.insert(self.animatedSteering.nodes, entry);
			i = i + 1;		
		end;
		
		self.animatedSteering.movingParts = {};
		local i=0;
		while true do
			local baseName = string.format("vehicle.animatedSteering.movingPart(%d)", i);
			if not hasXMLProperty(xmlFile, baseName) then
				break;
			end;	
			local index = getXMLString(xmlFile, baseName.."#node")
			local node = Utils.indexToObject(self.components, index);
			local found = false;
			for _, movingPart in pairs(self.movingParts) do
				if movingPart.node == node then
					found = true;
					table.insert(self.animatedSteering.movingParts, movingPart);
					break;
				end;
			end;
			
			if not found then
				print("AnimatedSteering-Error: movingPart '".. index .."' not found");
			end;
			i = i + 1;
		end;
		self.updateSteeringCount = 0;
	end;
end;

function AnimatedSteering:delete()
end;

function AnimatedSteering:mouseEvent(posX, posY, isDown, isUp, button)
end;

function AnimatedSteering:keyEvent(unicode, sym, modifier, isDown)
end;

function AnimatedSteering:update(dt)
	if self.animatedSteering ~= nil then
		if self:getIsActive() or self.updateSteeringCount > 0 then
			local wheel = self.animatedSteering.refWheel;
			local percent = math.abs(wheel.steeringAngle / wheel.rotMax);
			if wheel.steeringAngle <= 0 then
				percent = math.abs(wheel.steeringAngle / wheel.rotMin);
			end;
			
			for _, node in pairs(self.animatedSteering.nodes) do
				if wheel.steeringAngle > 0 then
					setRotation(node.index, node.xMax * percent, 0, 0);
				else 
					setRotation(node.index, node.xMin * percent, 0, 0);
				end;
			end;
			for _, part in pairs(self.animatedSteering.movingParts) do
				Cylindered.updateMovingPart(self, part);
			end;
			self.updateSteeringCount = self.updateSteeringCount - 1;
		end;
	end;
end;

function AnimatedSteering:updateTick(dt)
end;

function AnimatedSteering:draw()
end;

function AnimatedSteering:onLeave()
	self.updateSteeringCount = 200;
end;

